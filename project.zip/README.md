# BIOBOSS

This is our final project to end off the Fall semester of CS50

## Overview of the project

### Video Demo: https://youtu.be/NC50BWEpx8k

### Description:
Our final project is a website trivia game that allows users to play quizzes, get scores and learn some bilogy facts along the way if they didn't know them already. Currently, the user can choose from 3 different biology topics for the quiz (plants, genetics and geology), but the set up fo the quiz display is dynamic, not hard-coded. The questions and answers are stored in a database, so more quizzes can be added relatively easily.

## For the implementation of this project we used
- python (for the backend),
- flask web framework,
- CSS - for style ,
- SQL - for storing tables (database) and jinja templating (for dynamic HTML pages)

## Getting Started

### SQL

All of our quiz information, as said before is stored in the bioboss database (bioboss.db), along with user information.

The bioboss.db is required to run this website, since most functions first requre access to the database to run. Most routes must interact with the database, either for modification or acessing information purposes, so this bioboss.db should be sotred in the same directory as the python file.

The bioboss database contains 6 tables:
answers, questions, quizzes, users, users_response and user_quiz_scores. Ensure all tables are present in the database before running the web app.

### cs50.dev
cs50.dev is sufficient for running this web app, since it was used to create it. Follow the usage directions inf the section below if using cs50.dev to run this program.

## Usage
1. Download the project.zip file
    - This should include the following folders and the corresponding files:
        - bioboss.db
        - bioboss.py
        - DESIGN.md
        - READme.md
        - static/
        - static/genetics.png
        - static/plants.png
        - static/style.css
        - static/geology.png
        - templates/
        - templates/quiz.html
        - templates/quiz_page.html
        - templates/register.html
        - templates/logout.html
        - templates/submit_quiz.html
        - templates/login.html
        - templates/index.html
        - templates/navbar.html
        - templates/user_profile.html

2. Clear the working directory by running cd in the terminal window.
3. Create a directory by running this command in the terminal window: mkdir bioboss
4. If the zip folder has been downloaded, upload/drag and drop the file into your file explorer in cs50.dev into the bioboss directory.
5. Enter the Bioboss directory by running this command in the terminal window: cd bioboss
6. Unzip file by running this command in the terminal window: unzip project.zip
7. Remove the zip file with rm project.zip
8. Check that you have all the files listed above.
9. Run the following command in the terminal: python bioboss.py
10. Then run: export FLASK_APP=bioboss
11. Finally, run: flask run
12. Click the link generated
13. Register, then log in to be able to access the quiz modules.
14. Have fun playing Bioboss!




Authors
Nia Faith Lewis
Yusuf Yildirim


